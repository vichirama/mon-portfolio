// script.js
console.log('Portfolio Rama');